package com.alexandre.Todo_SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoSpringBootApplication.class, args);
	}

}
